// script.js
// Este script adiciona um efeito interativo ao botão de magia.

document.addEventListener('DOMContentLoaded', function () {
    const button = document.getElementById('magicButton');
    const message = document.getElementById('magicMessage');

    button.addEventListener('click', function () {
        // Alterna a visibilidade da mensagem
        message.classList.toggle('hidden');

        // Exibe uma mensagem alegre quando visível
        if (!message.classList.contains('hidden')) {
            message.textContent = 'Você é uma princesa, Klai! 👑✨';
        } else {
            message.textContent = '';
        }
    });
});